create function st_assvg(text) returns text
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$
SELECT public.ST_AsSVG($1::public.geometry,0,15);
$$;

alter function st_assvg(text) owner to postgres;

